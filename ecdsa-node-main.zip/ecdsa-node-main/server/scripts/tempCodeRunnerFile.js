let ss = generateSignature("b7c9b928003d188151a1", PRIVATE_KEY_1);
// console.log(ss);